<input type="text" name="_speaker_twitter_link" id="speaker_twitter_link" style="width: 95%;" value="<?=  $speaker_twitter_link; ?>" />
<input type="hidden" name="_speaker_twitter_link_nonce" value="<?=  wp_create_nonce('tedx_speaker_twitter_link_nonce');?>" />
<p class="description">The full url to the speakers twitter account (eg. <strong>http://twitter.com/BarackObama</strong>)</p>
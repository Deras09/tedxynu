<input type="text" name="_team_twitter_link" id="team_twitter_link" style="width: 95%;" value="<?=  $team_twitter_link; ?>" />
<input type="hidden" name="_team_twitter_link_nonce" value="<?=  wp_create_nonce('tedx_team_twitter_link_nonce');?>" />
<p class="description">The full url to the team member's twitter account (eg. <strong>https://twitter.com/twg</strong>)</p>
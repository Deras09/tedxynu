<input type="text" name="_team_job_description" id="team_job_description" style="width: 95%;" value="<?=  $team_job_description; ?>" />
<input type="hidden" name="_team_job_description_nonce" value="<?=  wp_create_nonce('tedx_team_job_description_nonce');?>" />
<p class="description">eg. Strategic Director</p>
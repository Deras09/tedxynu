<textarea id="schedule_item_extra_html" name="_schedule_item_extra_html"><?=  $schedule_item_extra_html ?></textarea>
<p class="description">Allows extra HTML to be appended into the schedule item box <em>(used for buttons)</em></p>
<input type="hidden" name="_schedule_item_extra_html_nonce" value="<?=  wp_create_nonce('tedx_schedule_item_extra_html_nonce');?>" />

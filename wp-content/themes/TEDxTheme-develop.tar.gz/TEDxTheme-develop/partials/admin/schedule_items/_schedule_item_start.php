<input type="text" name="_schedule_item_start" id="schedule_item_start" value="<?=  $schedule_item_start ?>">
<p class="description">The time when the event item begins</p>
<input type="hidden" name="_schedule_item_start_nonce" value="<?=   wp_create_nonce('tedx_schedule_item_start_nonce');?>" />

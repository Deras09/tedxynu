<p><strong>Speaker Role</strong></p>
<input type="text" name="_talk_speaker_role" id="talk_speaker_role" style="width: 95%;" value="<?=  $talk_speaker_role; ?>"/>
<input type="hidden" name="_talk_speaker_role_nonce" value="<?=  wp_create_nonce('tedx_talk_speaker_role_nonce'); ?>"/>
<p class="description">The role of the speaker (eg. Author, Musician, Dancer)</p>

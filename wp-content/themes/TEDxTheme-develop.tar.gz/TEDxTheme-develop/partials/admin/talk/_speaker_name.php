<p><strong>Speaker Name</strong></p>
<input type="text" name="_talk_speaker_name" id="talk_speaker_name" style="width: 95%;" value="<?=  $talk_speaker_name; ?>"/>
<input type="hidden" name="_talk_speaker_name_nonce" value="<?=  wp_create_nonce('tedx_talk_speaker_name_nonce'); ?>"/>
<p class="description">The name of the speaker</p>
